﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatternProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            int inputValue = 0;
            char[] chArray = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            Console.WriteLine("Please enter number between 1 t 26");

            //validation
            try
            {
                inputValue = Convert.ToInt32(Console.ReadLine());
                if (inputValue < 1 || inputValue > 26)
                {
                    Console.WriteLine("You have not entered valid number");
                    Console.WriteLine("Enter any key to exist");
                    Console.Read();
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("You have not entered valid number");
                Console.WriteLine("Enter any key to exist");
                Console.Read();
                return;
            }

            if (inputValue > 0)
            {
                for (int i = inputValue; i > 1; i--)
                {
                    //Initail Spaces logic upper left triagnle
                    for (int j = 0; j < i; j++)
                        Console.Write("  ");

                    //letter printing upper left triangle
                    for (int k = i; k <= inputValue; k++)
                    {
                        Console.Write(chArray[25 - (inputValue - k)] + " ");
                    }

                    //letter printing upper right triangle
                    int iCnt = 1;
                    for (int k = i; k < inputValue; k++)
                    {
                        Console.Write(chArray[25 - iCnt] + " ");
                        iCnt++;
                    }

                    //space  logic for upper right triangle
                    for (int j = 0; j < i; j++)
                        Console.Write("  ");

                    Console.WriteLine();
                }

                for (int i = 1; i < (inputValue + 1); i++)
                {
                    //space logic for bottom left triangle
                    for (int j = 0; j < i; j++)
                        Console.Write("  ");

                    //letter printing bottom left triangle
                    for (int k = i; k <= inputValue; k++)
                    {
                        Console.Write(chArray[25 - (inputValue - k)] + " ");
                    }

                    //letter printing bottom right triangle
                    int iCnt = 1;
                    for (int k = i; k < inputValue; k++)
                    {
                        Console.Write(chArray[25 - iCnt] + " ");
                        iCnt++;
                    }

                    //space  logic for bottom right triangle
                    for (int j = 0; j < i; j++)
                        Console.Write("  ");

                    Console.WriteLine();
                }
            }
            Console.WriteLine("Enter any key to exit");
            Console.Read();
        }
    }
}
