
/****** Object:  Table [dbo].[books]    Script Date: 25-09-2020 01:59:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[books](
	[Id] [int] NOT NULL,
	[title] [varchar](250) NULL,
	[year] [int] NULL,
	[author] [varchar](250) NULL,
 CONSTRAINT [PK_books] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ratings]    Script Date: 25-09-2020 01:59:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ratings](
	[reviewer_id] [int] NULL,
	[book_id] [int] NULL,
	[rating] [int] NULL,
	[rating_date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[reviewers]    Script Date: 25-09-2020 01:59:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[reviewers](
	[Id] [int] NOT NULL,
	[name] [varchar](250) NULL,
 CONSTRAINT [PK_reviewers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[books] ([Id], [title], [year], [author]) VALUES (101, N'A Tale Of Two Cities', 1859, N'Charles Dickens')
GO
INSERT [dbo].[books] ([Id], [title], [year], [author]) VALUES (102, N'The Lord of the Rings', 1955, N'J. R. R. Tolkien')
GO
INSERT [dbo].[books] ([Id], [title], [year], [author]) VALUES (103, N'The Hobbit', 1937, NULL)
GO
INSERT [dbo].[books] ([Id], [title], [year], [author]) VALUES (104, N'The Little Prince', 1943, N'Antoine de Saint-Exupéry')
GO
INSERT [dbo].[ratings] ([reviewer_id], [book_id], [rating], [rating_date]) VALUES (15201, 101, 2, CAST(N'2015-02-11' AS Date))
GO
INSERT [dbo].[ratings] ([reviewer_id], [book_id], [rating], [rating_date]) VALUES (15201, 101, 4, CAST(N'2015-06-16' AS Date))
GO
INSERT [dbo].[ratings] ([reviewer_id], [book_id], [rating], [rating_date]) VALUES (53202, 103, 4, NULL)
GO
INSERT [dbo].[reviewers] ([Id], [name]) VALUES (15201, N'Joe Martinez')
GO
INSERT [dbo].[reviewers] ([Id], [name]) VALUES (44203, N'John Smith')
GO
INSERT [dbo].[reviewers] ([Id], [name]) VALUES (53202, N'Alice Lewis')
GO
/****** Object:  StoredProcedure [dbo].[PRC_Get_Books_By_Rating]    Script Date: 25-09-2020 01:59:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [dbo].[PRC_Get_Books_By_Rating]
    @rating    int = 0
AS 
BEGIN
    
    SELECT distinct 
        a.title 
    FROM books a
    JOIN ratings b on a.Id = b.book_id
    WHERE 
        b.rating >= @rating
    ORDER BY 
        a.title ASC
END
GO

